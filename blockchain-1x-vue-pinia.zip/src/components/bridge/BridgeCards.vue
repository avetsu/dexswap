<script setup>
defineProps({
  fromName: String,
  toName: String,
  logoUrlFrom: String,
  logoUrlTo: String,
});
</script>

<template>
  <ul class="bridge__cards">
    <li class="bridge__cards-item">
      <span class="bridge__cards-img">
        <img :src="logoUrlFrom" alt="" />
      </span>
      <div class="bridge__cards-content">
        <span class="bridge__cards-text">From</span>
        <span class="bridge__cards-name">{{ fromName }}</span>
      </div>
    </li>
    <li class="bridge__cards-arrow">
      <svg
        width="16"
        height="12"
        viewBox="0 0 16 12"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M1 6L14.3333 6M14.3333 6L9.33333 1M14.3333 6L9.33333 11"
          stroke="white"
          stroke-width="1.66667"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </li>
    <li class="bridge__cards-item">
      <span class="bridge__cards-img">
        <img :src="logoUrlFrom" alt="" />
      </span>
      <div class="bridge__cards-content">
        <span class="bridge__cards-text">To</span>
        <span class="bridge__cards-name">{{ toName }}</span>
      </div>
    </li>
  </ul>
</template>

<style scoped>
.bridge__cards {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  margin-bottom: 17px;
}

@media (max-width: 375px) {
  .bridge__cards {
    margin-bottom: 12px;
  }
}
.bridge__cards-item {
  display: flex;
  align-items: center;
  gap: 19px;
  padding: 16px 14px;
  border: 0.49px solid #ffffff38;
  border-radius: 5px;
  backdrop-filter: blur(5.955679416656494px);
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.25);
  background: rgba(255, 255, 255, 0.05);
  width: 100%;
}

.bridge__cards-img {
  width: 40px;
  height: 40px;
  background-color: #d9d9d9;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}
@media (max-width: 576px) {
  .bridge__cards-item {
    padding: 10px;
    gap: 14px;
  }
  .bridge__cards-img {
    width: 30px;
    height: 30px;
  }
}
.bridge__cards-content {
  display: flex;
  flex-direction: column;
}

.bridge__cards-text {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(8px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
}
.bridge__cards-name {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(13px, 3vw, 18px);
  color: #fff;
}

.bridge__cards-arrow {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: #2a2a31;
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1;
}
</style>
