<script setup>
defineProps({
  name: String,
});
</script>

<template>
  <div class="bridge-amount">
    <span class="bridge-amount__text">Enter Amount</span>
    <div class="bridge-amount__input-wrapper">
      <input type="text" class="bridge-amount__input" />
      <span class="bridge-amount__input-text">{{ name }}</span>
    </div>
    <div class="bridge-amount__max">
      <span class="bridge-amount__available"> 0 ETH Available </span>
      <span class="bridge-amount__max-text"> Max </span>
    </div>
  </div>
</template>

<style scoped>
.bridge-amount {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 44px;
}
@media (max-width: 375px) {
  .bridge-amount {
    margin-bottom: 54px;
  }
}
.bridge-amount__text {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(8px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
  align-self: start;
}
.bridge-amount__input-wrapper {
  position: relative;
}
.bridge-amount__input {
  border: 1px solid #ffffff38;
  border-radius: 10px;
  height: 48px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(255, 255, 255, 0.05);
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(10px, 3vw, 15px);
  color: #fff;
  padding: 15px 25px;
  width: 100%;
}
.bridge-amount__input-text {
  position: absolute;
  right: 37px;
  top: 15px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(10px, 3vw, 15px);
  color: #fff;
}
.bridge-amount__max {
  display: flex;
  align-items: center;
  align-self: end;
  gap: 14px;
}

@media (max-width: 375px) {
  .bridge-amount__max {
    display: none;
  }
}
.bridge-amount__available {
  font-family: var(--font-family);
  font-weight: 275;
  font-size: 15px;
  color: #fff;
  opacity: 0.5;
}

.bridge-amount__max-text {
  border-radius: 20px;
  background: rgba(217, 217, 217, 0.05);
  padding: 5px 12px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 12px;
  color: #fff;
}
</style>
