<script setup>
import BridgeCards from '@/components/bridge/BridgeCards.vue';
import BridgeAmount from '@/components/bridge/BridgeAmount.vue';
import BridgeTransferTime from '@/components/bridge/BridgeTransferTime.vue';
import UIButton from '@/components/ui/UIButton.vue';
import { ref } from 'vue';

const cardsData = ref({
  fromName: 'Cyber',
  toName: 'Ethereum',
  logoUrlFrom: '',
  logoUrlTo: '',
});

const transferData = ref({
  time: '~7 days',
  geas: '0.000072 ETH',
});
</script>

<template>
  <div class="bridge-withdraw">
    <BridgeCards
      :fromName="cardsData.fromName"
      :toName="cardsData.toName"
      :logoUrlFrom="cardsData.logoUrlFrom"
      :logoUrlTo="cardsData.logoUrlTo"
    />
    <BridgeAmount :name="cardsData.fromName" />
    <BridgeTransferTime :time="transferData.time" :geas="transferData.geas" />
    <UIButton> Withdraw </UIButton>
  </div>
</template>

<style scoped>
.bridge-withdraw {
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(217, 217, 217, 0.05);
  padding: 20px;
  display: flex;
  flex-direction: column;
}
</style>
