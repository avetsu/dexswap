<script setup>
import { ref } from 'vue';

const nftItems = ref([
  {
    cardName: 'noname.eth',
    name: 'NAME NFT',
    count: '0,04 ETH',
  },
  {
    cardName: 'noname.eth',
    name: 'NAME NFT',
    count: '0,04 ETH',
  },
  {
    cardName: 'noname.eth',
    name: 'NAME NFT',
    count: '0,04 ETH',
  },
  {
    cardName: 'noname.eth',
    name: 'NAME NFT',
    count: '0,04 ETH',
  },
]);
</script>

<template>
  <ul class="nft__list">
    <li class="nft__item" v-for="nft in nftItems" :key="nft.name">
      <div class="nft__item-card">
        <span class="nft__item-card-text">
          {{ nft.cardName }}
        </span>
      </div>
      <div class="nft__item-content">
        <span class="nft__item-name">
          {{ nft.name }}
        </span>
        <span class="nft__item-count">
          {{ nft.count }}
        </span>
      </div>
    </li>
  </ul>
</template>

<style scoped>
.nft__list {
  display: flex;
  flex-wrap: wrap;
  width: 100%;
  gap: 9px;
}

.nft__item {
  display: flex;
  flex-direction: column;
  gap: 9px;
}

.nft__item-card {
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(255, 255, 255, 0.05);

  display: flex;
  align-items: end;
  max-width: 137px;
  width: 100%;
  padding: 115px 28px 10px 10px;
}

.nft__item-card-text {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 18px;
  color: #fff;
}
.nft__item-content {
  display: flex;
  flex-direction: column;
  gap: 2px;
  align-items: start;
}
.nft__item-name {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 12px;
  color: #fff;
}

.nft__item-count {
  font-family: var(--font-family);
  font-weight: 300;
  font-size: 10px;
  text-align: right;
  color: #fff;
  opacity: 0.5;
}
</style>
