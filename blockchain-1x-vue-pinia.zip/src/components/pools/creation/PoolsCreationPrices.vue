<script setup>
import { usePoolPricesStore } from '@/stores/PoolPricesStore';
import PoolsCreationPricesFilled from '@/components/pools/creation/PoolsCreationPricesFilled.vue';
import { storeToRefs } from 'pinia';

const pricesStore = usePoolPricesStore();

const { isFilledPrice, wallets, currentRange, ranges } = storeToRefs(pricesStore);

const { changeStatusWallet, changeStatusRange, onMinInput, onMaxInput } = pricesStore;
</script>

<template>
  <div class="pools-creation-price" v-if="!isFilledPrice">
    <div class="pools-creation-price__head">
      <span class="pools-creation-price__head-title"> Установить ценовой диапазон </span>
      <div class="pools-creation-price__head-btns">
        <button
          class="pools-creation-price-head-btn"
          :class="{ active: wallet.isActive }"
          v-for="wallet in wallets"
          :key="wallet.id"
          @click="changeStatusWallet(wallet.id)"
        >
          <span>{{ wallet.name }}</span>
        </button>
      </div>
    </div>

    <div
      class="pools-creation-price__range"
      :class="{
        'first-active': currentRange === ranges[0].name,
        'second-active': currentRange === ranges[1].name,
      }"
    >
      <button
        class="pools-creation__range-btn"
        :class="{ active: range.isActive }"
        v-for="range in ranges"
        :key="range.id"
        @click="changeStatusRange(range.id)"
      >
        {{ range.name }}
      </button>
    </div>

    <div class="pools-creation-price__current">
      <span class="pools-creation-price__current-text">
        Предоставление полного спектра ликвидности гарантирует постоянное участие на рынке по всем
        возможным ценам, обеспечивая простоту, но с потенциалом более высоких непостоянных потерь.
      </span>
      <div class="pools-creation-price__current-value">
        <span class="pools-creation-price__current-value-text">
          <span class="current-value-text__name">Текущая цена: </span>1 BNB = 563,243 USDT
          <span class="current-value-text__dollar">($563,243)</span>
        </span>
      </div>
      <div class="pools-creation-price__minmax">
        <div class="pools-creation-price__min">
          <span class="pools-creation-price__min-name"> Мин. цена </span>
          <input
            type="text"
            name="min-price"
            id="min-price"
            class="pools-creation-price__min-input"
            value="0"
            @input="onMinInput"
          />
          <span class="pools-creation-price__min-trade">
            {{ wallets.find((item) => item.isActive === false).name }} за
            {{ wallets.find((item) => item.isActive === true).name }}
          </span>
        </div>
        <div class="pools-creation-price__max">
          <span class="pools-creation-price__max-name"> Макс. цена </span>
          <input
            type="text"
            name="min-price"
            id="min-price"
            class="pools-creation-price__max-input"
            value="∞"
            @input="onMaxInput"
          />
          <span class="pools-creation-price__max-trade">
            {{ wallets.find((item) => item.isActive === false).name }} за
            {{ wallets.find((item) => item.isActive === true).name }}
          </span>
        </div>
      </div>
    </div>
  </div>
  <transition name="blur" mode="out-in">
    <PoolsCreationPricesFilled v-if="isFilledPrice" />
  </transition>
</template>

<style scoped>
.blur-enter-active {
  transition:
    opacity 0.5s ease,
    filter 0.5s ease;
}
.blur-enter-from {
  opacity: 0;
  filter: blur(10px);
}
.pools-creation-price {
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  background: rgba(217, 217, 217, 0.05);
  padding: 25px;
  display: flex;
  flex-direction: column;
  gap: 25px;
}

@media (max-width: 576px) {
  .pools-creation-price {
    border: none;
    backdrop-filter: none;
    background: transparent;
    padding: 0;
    gap: 15px;
  }
}

.pools-creation-price__head {
  display: flex;
  align-items: center;
  gap: 30px;
  justify-content: space-between;
}

.pools-creation-price__head-title {
  font-family: var(--font-family);
  font-weight: 500;
  font-size: clamp(15px, 3vw, 20px);
  color: #fff;
}

.pools-creation-price__head-btns {
  display: flex;
  gap: 12px;
}
.pools-creation-price-head-btn {
  border-radius: 20px;
  max-width: fit-content;
  padding: 5px 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(217, 217, 217, 0.05);
  transition: all 0.3s ease;
}
.pools-creation-price-head-btn span {
  font-family: var(--font-family);
  font-weight: 300;
  font-size: 12px;
  color: #fff;
  opacity: 0.5;
  transition: all 0.3s ease;
}

.pools-creation-price-head-btn.active {
  background: #58ff84;
}

.pools-creation-price-head-btn.active span {
  font-weight: 450;
  color: #161c20;
}

.pools-creation-price__range {
  display: flex;
  align-items: center;
  padding: 8px 10px;
  width: 100%;
  border: 1px solid #ffffff38;
  border-radius: 50px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(217, 217, 217, 0.05);
  justify-content: space-between;
  position: relative;
}

.pools-creation-price__range::before {
  content: '';
  width: 50%;
  height: 33px;
  display: block;
  border: 2px solid #58ff84;
  border-radius: 50px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: #58ff84;
  position: absolute;
  left: 10px;
  z-index: -1;
  transition: all 0.3s ease;
}

.first-active::before {
  left: 10px;
}
.second-active::before {
  left: 48.5%;
}

.pools-creation__range-btn {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(10px, 3vw, 14px);
  color: #fff;
  border: 2px solid transparent;
  border-radius: 50px;
  max-width: 50%;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px;
  transition: all 0.3s ease;
}

.pools-creation__range-btn.active {
  color: #161c20;
}
@media (max-width: 576px) {
  .pools-creation-price__range::before {
    display: none;
  }
  .pools-creation__range-btn.active {
    backdrop-filter: blur(12.100000381469727px);
    box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
    background: #58ff84;
  }
}

.pools-creation-price__current {
  display: flex;
  flex-direction: column;
}
.pools-creation-price__current-text {
  font-family: var(--font-family);
  font-weight: 300;
  font-size: 12px;
  color: #fff;
  opacity: 0.5;
  max-width: 638px;
  margin-bottom: 16px;
}

.pools-creation-price__current-value {
  border: 1px solid #ffffff38;
  border-radius: 8px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(217, 217, 217, 0.05);
  padding: 17px 23px 23px 23px;
  display: flex;
  align-items: center;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(14px, 3vw, 16px);
  color: #fff;
  margin-bottom: 26px;
}

@media (max-width: 576px) {
  .pools-creation-price__current-value {
    margin-bottom: 10px;
    padding: 16px 10px 25px 10px;
  }
}

.current-value-text__name {
  opacity: 0.5;
}

.current-value-text__dollar {
  opacity: 0.5;
  font-size: 14px;
}

.pools-creation-price__minmax {
  display: flex;
  gap: 25px;
}
@media (max-width: 576px) {
  .pools-creation-price__minmax {
    flex-direction: column;
    gap: 10px;
  }
}

.pools-creation-price__min,
.pools-creation-price__max {
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
}

.pools-creation-price__min-input,
.pools-creation-price__max-input {
  padding: 32px 23px 36px 23px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(217, 217, 217, 0.05);
  border: 1px solid #ffffff38;
  border-radius: 8px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 22px;
  color: #fff;
  width: 100%;
}

.pools-creation-price__min-name,
.pools-creation-price__max-name {
  position: absolute;
  left: 23px;
  top: 13px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(11px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
  z-index: 1;
}

.pools-creation-price__min-trade,
.pools-creation-price__max-trade {
  position: absolute;
  bottom: 16px;
  left: 23px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(11px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
}
@media (max-width: 576px) {
  .pools-creation-price__min-input,
  .pools-creation-price__max-input {
    padding: 30px 14px 35px 14px;
  }
  .pools-creation-price__min-name,
  .pools-creation-price__max-name {
    left: 14px;
  }
  .pools-creation-price__min-trade,
  .pools-creation-price__max-trade {
    left: 14px;
  }
}
</style>
