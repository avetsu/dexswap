<script setup>
import AppModal from '@/components/AppModal.vue';
import UIButtonModal from '@/components/ui/UIButtonModal.vue';
import { ref, provide } from 'vue';
import { usePoolDepositStore } from '@/stores/PoolDepositStore';
import { storeToRefs } from 'pinia';

const depositStore = usePoolDepositStore();

const { firstValue, max, secondValue } = storeToRefs(depositStore);

const { onFirstInput, setMaxFirst, onSecondInput, setMaxSecond } = depositStore;

const isModalOpen = ref(false);

const openModal = () => (isModalOpen.value = true);

const closeModal = () => (isModalOpen.value = false);

provide('openModal', openModal);

const selectedUpperToken = ref({ name: 'USDT', logo: '/icons/tether-small.svg' });
const selectedBottomToken = ref({ name: 'BTC', logo: '/icons/bitcoin.svg' });

const openModalFor = ref(null);

const selectToken = (token) => {
  if (openModalFor.value === 'upper') {
    selectedUpperToken.value = { name: token.title, logo: token.logo };
  } else if (openModalFor.value === 'bottom') {
    selectedBottomToken.value = { name: token.title, logo: token.logo };
  }
  openModalFor.value = null;
};
</script>

<template>
  <AppModal :isOpen="isModalOpen" :type="'tokens'" @close="closeModal" @selectToken="selectToken" />
  <div class="pools-creation-deposit">
    <div class="pools-creation-deposit-head">
      <span class="pools-creation-deposit-head__title">Внести токены</span>
      <span class="pools-creation-deposit-head__text"
        >Укажите суммы токенов для вашего взноса в ликвидность.</span
      >
    </div>
    <div class="pools-creation-deposit__tokens">
      <div class="pools-creation-deposit__token-first">
        <input
          type="number"
          class="pools-creation-deposit__input-first"
          name="deposit-input-first"
          value="0,008"
          v-model="firstValue"
          @input="onFirstInput"
        />
        <button class="pools-creation-deposit__btn-max" @click="setMaxFirst">
          ${{ max.toLocaleString('ru-RU').replace('.', ',') }}
        </button>
        <span class="pools-creation-deposit__max-text">
          ${{ max.toLocaleString('ru-RU').replace('.', ',') }} USDT <span>Max</span>
        </span>
        <UIButtonModal
          class="pools-creation-deposit__modal-btn"
          :url="selectedUpperToken.logo"
          :text="selectedUpperToken.name"
          @click="
            openModalFor = 'upper';
            isModalOpen = true;
          "
        />
      </div>
      <div class="pools-creation-deposit__token-second">
        <input
          type="number"
          class="pools-creation-deposit__input-second"
          name="deposit-input-second"
          value="0,008"
          v-model="secondValue"
          @input="onSecondInput"
        />
        <button class="pools-creation-deposit__btn-max" @click="setMaxSecond">
          ${{ max.toLocaleString('ru-RU').replace('.', ',') }}
        </button>
        <span class="pools-creation-deposit__max-text">
          ${{ max.toLocaleString('ru-RU').replace('.', ',') }} USDT <span>Max</span>
        </span>
        <UIButtonModal
          class="pools-creation-deposit__modal-btn"
          :url="selectedBottomToken.logo"
          :text="selectedBottomToken.name"
          @click="
            openModalFor = 'bottom';
            isModalOpen = true;
          "
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
input[type='number']::-webkit-outer-spin-button,
input[type='number']::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
.pools-creation-deposit {
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  background: rgba(217, 217, 217, 0.05);
  padding: 25px;
  display: flex;
  flex-direction: column;
  gap: 19px;
}

.pools-creation-deposit-head {
  display: flex;
  flex-direction: column;
  gap: 9px;
}

.pools-creation-deposit-head__title {
  font-family: var(--font-family);
  font-weight: 500;
  font-size: clamp(15px, 3vw, 20px);
  color: #fff;
}

.pools-creation-deposit-head__text {
  font-family: var(--font-family);
  font-weight: 300;
  font-size: clamp(11px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
}

.pools-creation-deposit__tokens {
  display: flex;
  gap: 11px;
}
@media (max-width: 576px) {
  .pools-creation-deposit {
    border: none;
    backdrop-filter: none;
    background-color: transparent;
    padding: 0;
  }
  .pools-creation-deposit__tokens {
    flex-direction: column;
    gap: 10px;
  }
}
.pools-creation-deposit__token-first,
.pools-creation-deposit__token-second {
  position: relative;
  width: 100%;
}

.pools-creation-deposit__input-first,
.pools-creation-deposit__input-second {
  width: 100%;
  height: 90px;
  padding: 16px 0px 38px 22px;
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(255, 255, 255, 0.05);
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 30px;
  color: #fff;
  overflow: hidden;
}

.pools-creation-deposit__btn-max {
  position: absolute;
  left: 24px;
  bottom: 15px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 15px;
  color: #fff;
  opacity: 0.5;
  z-index: 1;
}

.pools-creation-deposit__max-text {
  display: flex;
  gap: 17px;
  position: absolute;
  right: 16px;
  bottom: 17px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 12px;
  text-align: center;
  color: rgba(255, 255, 255, 0.3);
}
.pools-creation-deposit__max-text span {
  color: #58ff84;
}
::v-deep(.pools-creation-deposit__modal-btn) {
  position: absolute;
  top: 15px;
  right: 16px;
  background-color: transparent;
}
::v-deep(.pools-creation-deposit__modal-btn svg) {
  display: none;
}
</style>
