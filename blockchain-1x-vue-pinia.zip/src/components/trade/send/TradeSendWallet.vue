<template>
  <form class="card__send-wallet">
    <span class="card__send-wallet-text">Введите адрес кошелька</span>
    <input type="text" class="card__send-wallet-input" />
  </form>
</template>

<style scoped>
.card__send-wallet {
  display: flex;
  flex-direction: column;
  gap: 12px;
  width: 100%;
}
.card__send-wallet-text {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(8px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
}
.card__send-wallet-input {
  background-color: rgba(217, 217, 217, 0.05);
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  height: 48px;
  padding: 15px 25px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(10px, 3vw, 15px);
  color: #fff;
}
</style>
