<template>
  <ul class="dropdown__list">
    <li class="dropdown__item">
      <span class="dropdown__item-name">Комиссия (0,25%)</span>
      <span class="dropdown__item-value"><strong>6,47 $</strong></span>
    </li>
    <li class="dropdown__item">
      <span class="dropdown__item-name">Комиссия сети</span>
      <span class="dropdown__item-value">&lt; 0,1$</span>
    </li>
    <li class="dropdown__item">
      <span class="dropdown__item-name">Маршрутизация заказа</span>
      <span class="dropdown__item-value"><strong>X1 Blockchain API</strong></span>
    </li>
    <li class="dropdown__item">
      <span class="dropdown__item-name">Влияние на цену</span>
      <span class="dropdown__item-value">-0,779%</span>
    </li>
    <li class="dropdown__item">
      <span class="dropdown__item-name">Макс. проскальзывание</span>
      <span class="dropdown__item-value"><strong>2,5%</strong></span>
    </li>
  </ul>
</template>

<style>
.dropdown__list {
  display: flex;
  flex-direction: column;
  gap: 15px;
  max-width: 480px;
  width: 100%;
}

.dropdown__item {
  display: flex;
  justify-content: space-between;
}

.dropdown__item-name {
  font-family: var(--font-family);
  font-weight: 250;
  font-size: clamp(13px, 3vw, 18px);
  color: #fff;
}

.dropdown__item-value {
  font-family: var(--font-family);
  font-weight: 250;
  font-size: clamp(13px, 3vw, 18px);
  color: #fff;
}
.dropdown__item-value strong {
  font-weight: 500;
}
</style>
