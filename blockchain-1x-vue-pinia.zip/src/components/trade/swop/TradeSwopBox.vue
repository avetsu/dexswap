<script setup>
import { ref } from 'vue';
import TradeSwopCards from '@/components/trade/TradeCards.vue';
import UIButton from '@/components/ui/UIButton.vue';
import TradeDropdown from '@/components/trade/swop/TradeDropdown.vue';
import TradeInProcess from '@/components/trade/swop/TradeInProcess.vue';

const inProgress = ref(false);
const btnStatus = ref(false);
const convert = () => {
  inProgress.value = true;
  btnStatus.value = true;
};
</script>

<template>
  <div class="swop__wrapper">
    <div class="swop__inner">
      <TradeSwopCards />
      <UIButton @click="convert" :progress="inProgress">Обменять</UIButton>
    </div>
    <Transition name="fade">
      <TradeDropdown v-if="!btnStatus" />
      <TradeInProcess v-else />
    </Transition>
  </div>
</template>

<style>
.swop__wrapper {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.swop__inner {
  border: 1px solid #ffffff38;
  border-radius: 10px;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background: rgba(217, 217, 217, 0.05);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}
</style>
