<script setup>
import TradeDropdownContent from '@/components/trade/swop/TradeDropdownContent.vue';
import { ref } from 'vue';

const isOpen = ref(false);

function toggleDropDown() {
  isOpen.value = !isOpen.value;
}
</script>

<template>
  <button class="dropdown__btn" @click="toggleDropDown()">
    <span class="dropdown__change"> 1 USDT = 0,09025 ETH </span>
    <span class="dropdown__dollar"> (333,2 $) </span>
    <svg
      :class="{ rotate: isOpen }"
      class="dropdown__arrow"
      width="14"
      height="8"
      viewBox="0 0 14 8"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M13 7L7 0.999999L1 7"
        stroke="#58FF84"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </button>
  <Transition name="fade">
    <TradeDropdownContent v-if="isOpen" />
  </Transition>
</template>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition:
    opacity 0.3s ease,
    transform 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}
button {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 17px;
}
.dropdown__change {
  font-family: var(--font-family);
  font-weight: 300;
  font-size: clamp(13px, 3vw, 18px);
  color: #fff;
}
.dropdown__dollar {
  font-family: var(--font-family);
  font-weight: 250;
  font-size: 16px;
  color: #fff;
  opacity: 0.5;
}
.dropdown__arrow {
  margin-left: auto;
  transition: transform 0.3s ease;
}
.rotate {
  transform: rotate(-180deg);
}
</style>
