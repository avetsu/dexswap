<script setup>
import { ref, provide } from 'vue';
import AppModal from '@/components/AppModal.vue';
import UIButtonModal from '@/components/ui/UIButtonModal.vue';
import ModalTokens from '@/components/modals/ModalTokens.vue';
const isModalOpen = ref(false);

const openModal = () => (isModalOpen.value = true);

const closeModal = () => (isModalOpen.value = false);

provide('openModal', openModal);

const prices = ref([
  {
    count: 'Рынок',
    price: 87602.25,
    isActive: true,
  },
  {
    count: '1%',
    price: 17602.25,
    isActive: false,
  },
  {
    count: '5%',
    price: 57602.25,
    isActive: false,
  },
  {
    count: '10%',
    price: 97602.25,
    isActive: false,
  },
]);

const changePrice = (index) => {
  prices.value.forEach((item, i) => {
    item.isActive = i === index;
  });
};

const selectedToken = ref({ name: 'USDT', logo: '/icons/tether-small.svg' });

const openModalFor = ref(null);

const selectToken = (token) => {
  selectedToken.value = { name: token.title, logo: token.logo };
  openModalFor.value = null;
};
</script>

<template>
  <AppModal :isOpen="isModalOpen" @close="closeModal">
    <ModalTokens @selectToken="selectToken" @close="closeModal" />
  </AppModal>
  <div class="limit__upper">
    <div class="limit__upper-content">
      <span class="limit__upper-title">
        Когда 1 BTC
        <img :src="'./icons/bitcoin-limit.svg'" alt="" />
      </span>
      <span class="limit__upper-value">
        {{ prices.find((item) => item.isActive).price.toLocaleString('ru-RU') }}
      </span>
      <div class="limit__upper-btns">
        <button
          class="limit__upper-btn"
          v-for="(item, index) in prices"
          :key="index"
          :class="{ active: item.isActive }"
          @click="changePrice(index)"
        >
          {{ item.count }}
        </button>
      </div>
    </div>
    <UIButtonModal
      class="limit__tokens-btn"
      :url="selectedToken.logo"
      :text="selectedToken.name"
      @click="isModalOpen = true"
    />
  </div>
</template>

<style scoped>
.limit__upper {
  display: flex;
  justify-content: space-between;
}

.limit__upper-content {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.limit__upper-title {
  display: flex;
  align-items: center;
  gap: 6px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(8px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
}
.limit__upper-value {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(21px, 3vw, 30px);
  color: #fff;
}

.limit__upper-btns {
  display: flex;
  align-items: center;
  gap: 7px;
}
.limit__upper-btn {
  border-radius: 20px;
  background: rgba(217, 217, 217, 0.05);
  font-family: var(--font-family);
  font-weight: 300;
  font-size: clamp(8px, 3vw, 12px);
  color: #fff;
  opacity: 0.5;
  padding: 5px;
}
.active {
  opacity: 1;
  font-weight: 400;
}
.limit__tokens-btn {
  margin-top: 7px;
  margin-right: 24px;
  display: flex;
  align-items: center;
  width: 100%;
  padding: 5px;
  background: rgba(217, 217, 217, 0.1);
  height: 35px;
  border-radius: 50px;
  gap: 11px;
}
::v-deep(.limit__tokens-btn svg) {
  display: none;
}
.limit__token-name {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: clamp(14px, 3vw, 20px);
  color: #fff;
}
@media (max-width: 576px) {
  .limit__tokens-btn {
    padding: 3px;
  }
  .limit__tokens-btn {
    max-width: 81px;
    gap: 8px;
  }
}
</style>
