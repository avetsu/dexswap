<script setup>
defineProps({
  progress: {
    type: Boolean,
    default: false,
  },
});
</script>

<template>
  <button :class="progress ? 'btn-in-process' : ''">
    <template v-if="!progress">
      <slot />
    </template>
    <span v-else> В процессе... </span>
  </button>
</template>

<style scoped>
button {
  border: 1px solid #23863d;
  border-radius: 10px;
  width: 100%;
  background: linear-gradient(360deg, #23863d 0%, #58ff84 100%);
  font-family: var(--font-family);
  font-weight: 600;
  font-size: 14px;
  text-align: center;
  color: #216634;
  padding: 17px 0;
  transition: all 0.3s ease;
}

.btn-in-process {
  background: linear-gradient(360deg, #1c1c23 0%, #24242a 100%);
  border: 1px solid rgba(255, 255, 255, 0.219);
  color: #fff;
  opacity: 0.5;
  pointer-events: none;
}
</style>
