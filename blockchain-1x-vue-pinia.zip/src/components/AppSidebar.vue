<script setup>
import { ref, provide } from 'vue';
import SideBarTokens from '@/components/sidebar/SidebarTokens.vue';
import SideBarNFT from '@/components/sidebar/SidebarNFT.vue';
import SideBarPools from '@/components/sidebar/SidebarPools.vue';
import SidebarActivity from '@/components/sidebar/SidebarActivity.vue';
import AppModal from '@/components/AppModal.vue';
import { inject } from 'vue';
import ModalQr from './modals/ModalQr.vue';

const isModalOpen = ref(false);

const openModal = () => (isModalOpen.value = true);
const closeModal = () => (isModalOpen.value = false);

provide('openModal', openModal);

const isSidebarOpen = inject('isSidebarOpen');
const toggleSidebar = inject('toggleSidebar');
const navBtns = ref([
  {
    name: 'token',
    text: 'Токены',
  },
  {
    name: 'nft',
    text: 'NFT',
  },
  {
    name: 'pools',
    text: 'Пулы',
  },
  {
    name: 'activity',
    text: 'Активность',
  },
]);

const activeTab = ref('token');

const changeActiveTab = (tabName) => {
  activeTab.value = tabName;
};
</script>

<template>
  <AppModal :isOpen="isModalOpen" @close="closeModal">
    <ModalQr @close="closeModal" />
  </AppModal>
  <Transition name="slide">
    <div v-if="isSidebarOpen" class="sidebar">
      <button @click="toggleSidebar" class="sidebar__close-btn">
        <svg
          width="20"
          height="22"
          viewBox="0 0 20 22"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M10.005 1V11M16.365 5.64C17.6234 6.89879 18.4803 8.50244 18.8273 10.2482C19.1743 11.9939 18.9959 13.8034 18.3146 15.4478C17.6334 17.0921 16.4798 18.4976 14.9998 19.4864C13.5199 20.4752 11.7799 21.0029 10 21.0029C8.2201 21.0029 6.48016 20.4752 5.00018 19.4864C3.5202 18.4976 2.36664 17.0921 1.68537 15.4478C1.00409 13.8034 0.825693 11.9939 1.17272 10.2482C1.51975 8.50244 2.37663 6.89879 3.635 5.64"
            stroke="white"
            stroke-opacity="0.6"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </button>
      <div class="sidebar__main">
        <span class="sidebar__main-wallet">
          <svg
            width="20"
            height="21"
            viewBox="0 0 20 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M14 6.43196V2.93261C14 2.10087 14 1.685 13.8248 1.42943C13.6717 1.20614 13.4346 1.05445 13.1678 1.00904C12.8623 0.957056 12.4847 1.13133 11.7295 1.47988L2.85901 5.57395C2.18551 5.8848 1.84875 6.04022 1.60211 6.28127C1.38406 6.49438 1.21762 6.75451 1.1155 7.04179C1 7.36675 1 7.73764 1 8.47942V13.432M14.5 12.932H14.51M1 9.63196L1 16.232C1 17.3521 1 17.9121 1.21799 18.3399C1.40973 18.7163 1.71569 19.0222 2.09202 19.214C2.51984 19.432 3.07989 19.432 4.2 19.432H15.8C16.9201 19.432 17.4802 19.432 17.908 19.214C18.2843 19.0222 18.5903 18.7163 18.782 18.3399C19 17.9121 19 17.3521 19 16.232V9.63196C19 8.51185 19 7.9518 18.782 7.52398C18.5903 7.14765 18.2843 6.84169 17.908 6.64995C17.4802 6.43196 16.9201 6.43196 15.8 6.43196L4.2 6.43196C3.0799 6.43196 2.51984 6.43196 2.09202 6.64994C1.7157 6.84169 1.40973 7.14765 1.21799 7.52398C1 7.9518 1 8.51185 1 9.63196ZM15 12.932C15 13.2081 14.7761 13.432 14.5 13.432C14.2239 13.432 14 13.2081 14 12.932C14 12.6558 14.2239 12.432 14.5 12.432C14.7761 12.432 15 12.6558 15 12.932Z"
              stroke="white"
              stroke-opacity="0.6"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <span class="sidebar__main-wallet-value">$ 8450<span>.00</span></span>
        </span>
        <span class="sidebar__main-height">
          <svg
            width="8"
            height="6"
            viewBox="0 0 8 6"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M4 6L0.535899 -6.52533e-07L7.4641 -4.68497e-08L4 6Z" fill="#E74E4E" />
          </svg>
          $0,12
        </span>
      </div>
      <button class="sidebar__get-token-btn" @click="openModal">
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M12 0C5.4 0 0 5.4 0 12C0 18.6 5.4 24 12 24C18.6 24 24 18.6 24 12C24 5.4 18.6 0 12 0ZM16.44 12.84L12.84 16.44C12.72 16.56 12.6 16.68 12.48 16.68C12.24 16.8 11.88 16.8 11.52 16.68C11.4 16.68 11.28 16.56 11.16 16.44L7.56 12.84C7.08 12.36 7.08 11.64 7.56 11.16C8.04 10.68 8.76 10.68 9.24 11.16L10.8 12.72V8.4C10.8 7.68 11.28 7.2 12 7.2C12.72 7.2 13.2 7.68 13.2 8.4V12.72L14.76 11.16C15.24 10.68 15.96 10.68 16.44 11.16C16.92 11.64 16.92 12.36 16.44 12.84Z"
            fill="#58FF84"
          />
        </svg>
        Получить
      </button>
      <nav class="sidebar__nav">
        <button
          v-for="button in navBtns"
          :class="{ active: activeTab === button.name }"
          class="sidebar__nav-btn"
          :key="button.name"
          @click="changeActiveTab(button.name)"
        >
          {{ button.text }}
        </button>
      </nav>

      <TransitionGroup tag="div" class="sidebar__content" name="out">
        <SideBarTokens v-if="activeTab === 'token'" />
        <SideBarNFT v-if="activeTab === 'nft'" />
        <SideBarPools v-if="activeTab === 'pools'" />

        <SidebarActivity v-if="activeTab === 'activity'" />
      </TransitionGroup>
    </div>
  </Transition>
</template>

<style scoped>
.out-enter-active {
  transition:
    opacity 1s ease,
    transform 0.5s ease;
}
.out-enter-from {
  opacity: 0;
  transform: translateY(-10px);
}
.sidebar {
  position: fixed;
  top: 80px;
  right: 13px;
  bottom: 10px;
  border: 1px solid #ffffff38;
  border-radius: 20px;
  background: rgba(217, 217, 217, 0.05);
  backdrop-filter: blur(96.69999694824219px);
  overflow-y: auto;
  padding: 19px;
  max-width: 321px;
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 24px;
  z-index: 10;
}

@media (max-width: 375px) {
  .sidebar {
    max-width: none;
    width: 95dvw;
  }
}
.sidebar__close-btn {
  position: fixed;
  top: 26px;
  right: 18px;
}
.sidebar__close-btn svg path {
  transition: all 0.3s ease;
}
.sidebar__close-btn:hover svg path {
  stroke-opacity: 1;
}

.sidebar::-webkit-scrollbar {
  width: 0;
  height: 0;
  display: none;
}

.sidebar__main {
  display: flex;
  flex-direction: column;
  gap: 4px;
  align-items: center;
  align-self: start;
}
.sidebar__main-wallet {
  display: flex;
  align-items: center;
  gap: 12px;
}
.sidebar__main-wallet-value {
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 23px;
  text-align: right;
  color: #fff;
}
.sidebar__main-wallet-value span {
  font-size: 11px;
}
.sidebar__main-height {
  display: flex;
  align-items: center;
  gap: 5px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.3);
}

.sidebar__get-token-btn {
  display: flex;
  align-items: center;
  gap: 16px;
  border-radius: 10px;
  background-color: rgba(217, 217, 217, 0.05);
  border: 1px solid #ffffff38;
  backdrop-filter: blur(12.100000381469727px);
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  width: 100%;
  padding: 18px 19px;
  font-family: var(--font-family);
  font-weight: 400;
  font-size: 12px;
  color: #fff;
}

.sidebar__nav {
  display: flex;
  align-items: center;
  gap: 23px;
}

.sidebar__nav-btn {
  font-family: var(--font-family);
  font-weight: 275;
  font-size: 16px;
  color: #fff;
}
.sidebar__content {
  position: relative;
}
.sidebar__nav-btn.active {
  font-weight: 600;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.slide-enter-active,
.slide-leave-active {
  transition: transform 0.3s ease;
}

.slide-enter-from,
.slide-leave-to {
  transform: translateX(100%);
}

.slide-enter-to,
.slide-leave-from {
  transform: translateX(0);
}
</style>
