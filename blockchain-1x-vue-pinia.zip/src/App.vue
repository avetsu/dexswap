<script setup>
import { ref } from 'vue';
import { RouterView } from 'vue-router';
import AppHeader from '@/components/AppHeader.vue';
import AppBurgerMenu from './components/AppBurgerMenu.vue';

const menuOpen = ref(false);
</script>

<template>
  <div class="app-wrapper">
    <AppBurgerMenu v-model:menuOpen="menuOpen" />
    <AppHeader v-model:menuOpen="menuOpen" />

    <RouterView />

    <img :src="'/img/background-blick.png'" class="background-blick" alt="" />
    <img :src="'/img/background-x.png'" class="background-x" alt="" />
  </div>
</template>

<style scoped>
.app-wrapper {
  overflow-y: auto;
  height: 100vh;
}

@media (max-width: 576px) {
  .app-wrapper {
    height: auto;
  }
}
.background-blick {
  position: absolute;
  z-index: -1;
  inset: 0;

  width: 100%;
}
.background-x {
  position: absolute;
  z-index: -2;
  top: 0;
  right: -23%;
  width: 70%;
  mix-blend-mode: overlay;
}

@media (max-width: 1000px) {
  .background-x {
    display: none;
  }
}
</style>
