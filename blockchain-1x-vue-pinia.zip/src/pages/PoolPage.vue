<script setup>
import PoolsDefault from '@/components/pools/default/PoolsDefault.vue';
import { computed } from 'vue';
import { useRoute } from 'vue-router';
const route = useRoute();
const isCreatePage = computed(() => route.path === '/pool/create');
</script>

<template>
  <PoolsDefault v-if="!isCreatePage" />
  <RouterView />
  <span class="background-word"> Pool </span>
</template>

<style scoped>
.background-word {
  font-family: var(--font-family);
  font-weight: 900;
  font-size: clamp(150px, 30vw, 353px);
  color: rgba(255, 255, 255, 0.22);
  mix-blend-mode: overlay;
  position: absolute;
  bottom: -8%;
  left: 50%;
  z-index: -1;
  text-transform: uppercase;
  transform: translateX(-50%);
}

@media (max-width: 576px) {
  .background-word {
    display: none;
  }
}
</style>
