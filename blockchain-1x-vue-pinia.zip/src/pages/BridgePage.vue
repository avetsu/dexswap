<script setup>
import BridgeNav from '@/components/bridge/BridgeNav.vue';
import BridgeDepositBox from '@/components/bridge/deposit/BridgeDepositBox.vue';
import BridgeWithdrawBox from '@/components/bridge/withdraw/BridgeWithdrawBox.vue';
import { ref, provide } from 'vue';

const btnStatus = ref(false);

provide('btnStatus', btnStatus);

const contentType = ref('deposit');

const updateContentType = (newType) => {
  contentType.value = newType;
};
</script>

<template>
  <div class="bridge-wrapper">
    <BridgeNav :contentType="contentType" @update-content="updateContentType" />
    <TransitionGroup tag="div" name="out" class="bridge-content" mode="in-out">
      <BridgeDepositBox v-if="contentType === 'deposit'" />
      <BridgeWithdrawBox v-if="contentType === 'withdraw'" />
    </TransitionGroup>
  </div>
  <span class="background-word"> BRIDGE </span>
</template>

<style scoped>
.out-enter-active {
  transition:
    opacity 1s ease,
    transform 0.5s ease;
}
.out-enter-from {
  opacity: 0;
  transform: translateY(-10px);
}
.bridge-wrapper {
  max-width: 510px;
  width: 100%;
  margin: 110px auto 0 auto;
  gap: 28px;
  display: flex;
  flex-direction: column;
  padding: 0 15px;
  min-height: 400px;
}

@media (max-width: 375px) {
  .bridge-content {
    padding: 15px 14px;
  }
}
.background-word {
  font-family: var(--font-family);
  font-weight: 900;
  font-size: clamp(150px, 30vw, 353px);
  color: rgba(255, 255, 255, 0.22);
  mix-blend-mode: overlay;
  position: absolute;
  bottom: -8%;
  left: 50%;
  z-index: -1;
  text-transform: uppercase;
  transform: translateX(-50%);
}

@media (max-width: 576px) {
  .background-word {
    display: none;
  }
}
</style>
