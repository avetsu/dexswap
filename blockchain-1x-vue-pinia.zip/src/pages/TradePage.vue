<script setup>
import TradeNav from '@/components/trade/TradeNav.vue';
import TradeSwopBox from '@/components/trade/swop/TradeSwopBox.vue';
import TradeLimitBox from '@/components/trade/limit/TradeLimitBox.vue';
import TradeSendBox from '@/components/trade/send/TradeSendBox.vue';

import Modal from '@/components/AppModal.vue';

import { ref, provide } from 'vue';

const btnStatus = ref(false);

provide('btnStatus', btnStatus);

const contentType = ref('swap');

const updateContentType = (newType) => {
  contentType.value = newType;
};
</script>
<template>
  <div class="trade__wrapper">
    <TradeNav :contentType="contentType" @update-content="updateContentType" />

    <TransitionGroup tag="div" name="out">
      <div class="trade__swop" v-if="contentType === 'swap'">
        <TradeSwopBox />
      </div>

      <div class="limit" v-if="contentType === 'limit'">
        <TradeLimitBox />
      </div>

      <div class="send" v-if="contentType === 'send'">
        <TradeSendBox />
      </div>
    </TransitionGroup>

    <span class="background-word">
      {{ contentType }}
    </span>
    <Modal />
  </div>
</template>

<style scoped>
.out-enter-active {
  transition:
    opacity 1s ease,
    transform 0.5s ease;
}
.out-enter-from {
  opacity: 0;
  transform: translateY(-10px);
}
.trade__wrapper {
  max-width: 510px;
  width: 100%;
  margin: 110px auto 0 auto;
  gap: 28px;
  display: flex;
  flex-direction: column;
  padding: 0 15px;
  min-height: 400px;
}
.trade__swop {
}
.fade-enter-active,
.fade-leave-active {
  transition:
    opacity 0.3s ease,
    transform 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

.background-word {
  font-family: var(--font-family);
  font-weight: 900;
  font-size: clamp(150px, 30vw, 353px);
  color: rgba(255, 255, 255, 0.22);
  mix-blend-mode: overlay;
  position: absolute;
  bottom: -8%;
  left: 50%;
  z-index: -1;
  text-transform: uppercase;
  transform: translateX(-50%);
}

@media (max-width: 576px) {
  .background-word {
    display: none;
  }
}
</style>
