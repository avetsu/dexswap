import { defineStore } from 'pinia';
import { ref, useId, computed } from 'vue';
import { usePoolStepsStore } from './PoolStepsStore';
export const usePoolPricesStore = defineStore('PoolPricesStore', () => {
  const stepsStore = usePoolStepsStore();

  const wallets = ref([
    {
      id: useId(),
      name: 'BNB',
      isActive: true,
    },
    {
      id: useId(),
      name: 'USDT',
      isActive: false,
    },
  ]);

  const ranges = ref([
    {
      id: useId(),
      name: 'Полный диапазон',
      isActive: true,
    },
    {
      id: useId(),
      name: 'Индивидуальный диапазон',
      isActive: false,
    },
  ]);

  const currentRange = computed(() => {
    return ranges.value.find((item) => item.isActive === true).name;
  });
  const changeStatusWallet = (index) => {
    wallets.value.forEach((item) => {
      item.isActive = item.id === index;
    });
  };

  const changeStatusRange = (index) => {
    ranges.value.forEach((item) => {
      item.isActive = item.id === index;
    });
  };

  const minValue = ref(0);
  const maxValue = ref(Infinity);

  const onMinInput = (e) => {
    minValue.value = e.target.value;
  };
  const onMaxInput = (e) => {
    maxValue.value = e.target.value;
  };

  const computedPrice = computed(() => {
    return {
      min: minValue.value,
      max: maxValue.value,
    };
  });

  const isFilledPrice = ref(false);

  const formDataPrice = computed(() => ({
    wallet: {
      selected: wallets.value.find((item) => item.isActive === true).name,
      notSelected: wallets.value.find((item) => item.isActive === false).name,
    },
    range: ranges.value.find((item) => item.isActive === true).name,
    minValue: minValue.value,
    maxValue: maxValue.value === Infinity ? '∞' : maxValue.value,
  }));

  const priceEditClick = () => {
    stepsStore.currentStep = 2;
    isFilledPrice.value = false;
  };

  const resetPrice = () => {
    minValue.value = 0;
    maxValue.value = '∞';
    ranges.value.forEach((item, i) => {
      item.isActive = false;
      if (i === 0) {
        item.isActive = true;
      }
    });
  };

  return {
    wallets,
    ranges,
    changeStatusWallet,
    changeStatusRange,
    onMinInput,
    onMaxInput,
    priceEditClick,
    currentRange,
    computedPrice,
    isFilledPrice,
    formDataPrice,
    resetPrice,
  };
});
